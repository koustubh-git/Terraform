# Example node.js project

This repo is to show how I am currently architecting my node.js projects.

Please feel free to use it as a basis for your own projects.

The interesting bit is currently in test/integration/user_sees_homepage.js - note how I'm stubbing out the response object.

I welcome patches and improvements.

# Testing options

* [Mario Aquino](http://github.com/marioaquino/example-nodejs-project) has added support for NoSpec on his branch.
* [James Carr](http://github.com/jamescarr/example-nodejs-project) has added JSpec support.
